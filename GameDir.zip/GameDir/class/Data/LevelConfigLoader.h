#pragma once
#include "LevelConfig.h"
#include "GameModel.h"
#include "json/document.h"
#include "json/filereadstream.h"
#include <string>
#include <cstdio>

// ���ü��ض���
class LevelConfigLoader {
public:
    // ���ݵ�����عؿ����������ļ�
    static LevelConfig loadLevelConfig(int levelId) {
        LevelConfig config;

        // �����ļ�·��
        std::string basePath = getLevelBasePath(levelId);
        std::string playfieldPath = basePath + "card1.json";
        std::string stackPath = basePath + "card2.json";

        // ���س�������
        if (!loadJsonFile(playfieldPath, config.doc1)) {
            printf("���س��������ļ�ʧ��: %s\n", playfieldPath.c_str());
        }

        // ������������
        if (!loadJsonFile(stackPath, config.doc2)) {
            printf("�������������ļ�ʧ��: %s\n", stackPath.c_str());
        }

        return config;
    }

private:
    // Json �ļ���Ŀ¼
    static std::string getLevelBasePath(int levelId) {
        char buffer[256];
        GetCurrentDirectoryA(256, buffer);
        std::string currentPath(buffer);
        return currentPath + "\\JsonCard\\Card" + std::to_string(levelId) + "\\";
    }

    // ���� json �ļ�
    static bool loadJsonFile(const std::string& filePath, rapidjson::Document& doc) {
        FILE* file = fopen(filePath.c_str(), "rb");
        if (!file) {
            return false;
        }

        char readBuffer[65536];
        rapidjson::FileReadStream is(file, readBuffer, sizeof(readBuffer));

        doc.ParseStream(is);
        fclose(file);

        return !doc.HasParseError();
    }
};

// ��������Ķ���ŵ� Json �����ȡ���ݷŵ� GameModel ��
class GameModelGenerator {
public:
    // �������ݵ� GameModel
    static std::shared_ptr<GameModel> generateGameModel(const LevelConfig& config) {
        auto model = std::make_shared<GameModel>();

        // �����������ã�Playfield��
        if (config.doc1.HasMember("Playfield") && config.doc1["Playfield"].IsArray()) {
            const auto& cards = config.doc1["Playfield"];
            for (rapidjson::SizeType i = 0; i < cards.Size(); i++) {
                const auto& card = cards[i];
                int face = card.HasMember("CardFace") ? card["CardFace"].GetInt() : 0;
                int suit = card.HasMember("CardSuit") ? card["CardSuit"].GetInt() : 0;

                model->playfieldCards.push_back(
                    std::make_shared<CardModel>((CardSuitType)suit, (CardFaceType)face, true)
                );
            }
        }

        // �����������ã�Stack��
        if (config.doc2.HasMember("Stack") && config.doc2["Stack"].IsArray()) {
            const auto& cards = config.doc2["Stack"];
            for (rapidjson::SizeType i = 0; i < cards.Size(); i++) {
                const auto& card = cards[i];
                int face = card.HasMember("CardFace") ? card["CardFace"].GetInt() : 0;
                int suit = card.HasMember("CardSuit") ? card["CardSuit"].GetInt() : 0;

                model->handCards.push_back(
                    std::make_shared<CardModel>((CardSuitType)suit, (CardFaceType)face, true)
                );
            }
        }
        return model;
    }
};