// 场景切换标识
#include "GameController.h"
bool GameController::_initialized = false;