#include "CardNode.h"
#include "Common.h"

USING_NS_CC;

CardNode* CardNode::create(std::shared_ptr<CardModel> model, bool isPlayfield) {
    CardNode* ret = new CardNode();
    if (ret && ret->init(model, isPlayfield)) {
        ret->autorelease();
        return ret;
    }
    CC_SAFE_DELETE(ret);
    return nullptr;
}

bool CardNode::init(std::shared_ptr<CardModel> model, bool isPlayfield) {
    if (!Node::init()) {
        return false;
    }

    _model = model;
    _isPlayfield = isPlayfield;

    setupCardDisplay();

    return true;
}

void CardNode::setupCardDisplay() {
    // 添加边框
    auto borderSize = Sprite::create(Util::GetPatternPath() + "\\card_general.png");
    float borderScale = 0.4f;
    borderSize->setScale(borderScale);
    borderSize->setPosition(Vec2::ZERO);
    this->addChild(borderSize);

    // 获取边框大小
    Size originalSize = borderSize->getContentSize();
    float borderWidth = originalSize.width * borderScale;
    float borderHeight = originalSize.height * borderScale;

    auto& paths = ResourcePaths::getInstance();

    // 大数字
    auto bigNum = Sprite::create(paths.getBigNumberPath(_model->getFace()));
    if (bigNum) {
        float bigScale = (borderWidth * 0.3f) / bigNum->getContentSize().width;
        bigNum->setScale(bigScale);
        bigNum->setPosition(Vec2::ZERO);
        this->addChild(bigNum);
    }

    // 小数字
    auto smallNum = Sprite::create(paths.getSmallNumberPath(_model->getFace()));
    if (smallNum) {
        float smallNumScale = (borderWidth * 0.15f) / smallNum->getContentSize().width;
        smallNum->setScale(smallNumScale);

        float smallNumWidth = smallNum->getContentSize().width * smallNumScale;
        float smallNumHeight = smallNum->getContentSize().height * smallNumScale;

        float margin = borderWidth * 0.05f;
        float x = -borderWidth / 2 + smallNumWidth / 2 + margin;
        float y = borderHeight / 2 - smallNumHeight / 2 - margin;

        smallNum->setPosition(Vec2(x, y));
        this->addChild(smallNum);
    }

    // 花色
    auto suit = Sprite::create(paths.getSuitPath(_model->getSuit()));
    if (suit) {
        float suitScale = (borderWidth * 0.15f) / suit->getContentSize().width;
        suit->setScale(suitScale);

        float suitWidth = suit->getContentSize().width * suitScale;
        float suitHeight = suit->getContentSize().height * suitScale;

        float margin = borderWidth * 0.05f;
        float x = borderWidth / 2 - suitWidth / 2 - margin;
        float y = borderHeight / 2 - suitHeight / 2 - margin;

        suit->setPosition(Vec2(x, y));
        this->addChild(suit);
    }
}