#include "GameView.h"
#include "SimpleAudioEngine.h"
#include "Util.hpp"
#include "GameController.h"
#include "AppDelegate.h"
USING_NS_CC;

// ��������
Scene* GameView::createScene() {
    return GameView::create();
}

// ������Ϸ���������л�����Ϸ����

void GameView::startGame(std::shared_ptr<GameModel> model) {
    _Scene = true;

    auto director = Director::getInstance();

    auto scene = GameView::create();
    auto gameView = dynamic_cast<GameView*>(scene);
    if (gameView) {
        gameView->setupGameBackground();
        gameView->setupControllers(model);
        gameView->setupCardViews();
    }

    if (director->getRunningScene()) {
        director->replaceScene(scene);
    }
    else {
        director->runWithScene(scene);
    }
}

// ������Ϸ����

void GameView::setupGameBackground() {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    float totalHeight = visibleSize.height;
    float brownHeight = totalHeight * 0.6f;
    float greenHeight = totalHeight * 0.4f;

    auto brownArea = LayerColor::create(Color4B(139, 69, 19, 255), visibleSize.width, brownHeight);
    brownArea->setPosition(Vec2(origin.x, origin.y + greenHeight));
    this->addChild(brownArea, -1);

    auto greenArea = LayerColor::create(Color4B(128, 0, 128, 255), visibleSize.width, greenHeight);
    greenArea->setPosition(Vec2(origin.x, origin.y));
    this->addChild(greenArea, -1);

    auto line = DrawNode::create();
    line->drawLine(Vec2(origin.x, origin.y + greenHeight),
        Vec2(origin.x + visibleSize.width, origin.y + greenHeight), Color4F::WHITE);
    this->addChild(line);
}

// ������ʼ��
bool GameView::init() {
    if (!Scene::init()) return false;
    if (!_Scene) setupUI();
    return true;
}

// ���ر���ͼƬ�������ؿ�ѡ��ť
void GameView::setupUI() {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto bg = Sprite::create(Util::GetMainPath());
    if (bg) {
        bg->setContentSize(visibleSize);
        bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        this->addChild(bg, -1);
    }
    createLevelButtons();
}

// �������˵��������Ϸ�ؿ���Դ
void GameView::returnToMainMenu() {
    cleanupGame();
    _Scene = false;

    auto scene = GameView::create();
    Director::getInstance()->replaceScene(scene);
}

// ������Ϸ����
void GameView::cleanupGame() {
    _playFieldController.reset();
    _stackController.reset();
    _undoManager.reset();
    _gameModel.reset();

    Director::getInstance()->getEventDispatcher()->removeAllEventListeners();
    this->stopAllActions();
    this->removeAllChildren();
}

// ��ʼ����Ϸ������
void GameView::setupControllers(std::shared_ptr<GameModel> model) {
    _gameModel = model;
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    _playFieldController = std::make_unique<PlayFieldController>();
    _playFieldController->init(model, this, origin);

    _stackController = std::make_unique<StackController>();
    _stackController->init(model, this, origin);

    _undoManager = std::make_unique<UndoManager>();
}

// ��ʼ��������ͼ

void GameView::setupCardViews() {
    _playFieldController->initView();
    _stackController->initView();
    setupCardListeners();

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    // ������ť
    auto undoItem = MenuItemFont::create("rollback", [this](Ref* sender) {
        onUndoClicked();
        });
    undoItem->setFontSize(40);
    undoItem->setPosition(Vec2(visibleSize.width - 100 + origin.x, visibleSize.height - 100 + origin.y));

    // ���ذ�ť
    auto backItem = MenuItemFont::create("go menu", [this](Ref* sender) {
        returnToMainMenu();
        });
    backItem->setFontSize(40);
    backItem->setPosition(Vec2(100 + origin.x, visibleSize.height - 100 + origin.y));

    auto menu = Menu::create(undoItem, backItem, nullptr);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 100);
}

// Ϊ���п������ô�������

void GameView::setupCardListeners() {
    for (auto cardNode : _playFieldController->getCardNodes()) {
        addCardTouchListener(cardNode);
    }
    for (auto cardNode : _stackController->getCardNodes()) {
        addCardTouchListener(cardNode);
    }
}

// Ϊ�����������Ӵ����¼�����

void GameView::addCardTouchListener(CardNode* cardNode) {
    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);

    listener->onTouchBegan = [this, cardNode](Touch* touch, Event* event) {
        Vec2 touchPos = touch->getLocation();
        Vec2 nodePos = cardNode->getPosition();
        Size nodeSize = Size(100, 150);
        Rect rect(nodePos.x - nodeSize.width / 2, nodePos.y - nodeSize.height / 2, nodeSize.width, nodeSize.height);

        if (rect.containsPoint(touchPos)) {
            onCardClicked(cardNode);
            return true;
        }
        return false;
        };

    Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, cardNode);
}

// ���Ƶ���¼�����

void GameView::onCardClicked(CardNode* cardNode) {
    if (!cardNode) return;

    if (cardNode->isPlayfield()) {
        handlePlayfieldEliminate(cardNode);
    }
    else {
        handleStackSwap(cardNode);
    }
}

// �������Ƶ�������߼�
 
void GameView::handlePlayfieldEliminate(CardNode* playfieldCard) {
    _playFieldController->onCardClicked(playfieldCard);

    auto topCard = _stackController->getTopCard();
    if (!topCard) return;

    int diff = abs((int)playfieldCard->getModel()->getFace() - (int)topCard->getModel()->getFace());
    if (diff == 1) {
        eliminateCardsPermanent(topCard, playfieldCard);
    }
}

// �������Ƶ�������߼�
void GameView::handleStackSwap(CardNode* clickedCard) {
    _stackController->onCardClicked(clickedCard);

    auto& cards = _stackController->getCardNodes();
    if (cards.size() < 2) return;

    CardNode* rightCard = cards.back();
    if (clickedCard == rightCard) return;

    recordSwapAction(clickedCard, rightCard);
    swapCards(clickedCard, rightCard);
}

// �����������Ƶ�λ�ú�˳��
void GameView::swapCards(CardNode* card1, CardNode* card2) {
    if (!card1 || !card2 || card1 == card2) return;

    auto& cards = _stackController->getCardNodes();
    auto& models = _gameModel->handCards;

    auto it1 = std::find(cards.begin(), cards.end(), card1);
    auto it2 = std::find(cards.begin(), cards.end(), card2);
    if (it1 != cards.end() && it2 != cards.end()) {
        std::iter_swap(it1, it2);
    }

    auto modelIt1 = std::find(models.begin(), models.end(), card1->getModel());
    auto modelIt2 = std::find(models.begin(), models.end(), card2->getModel());
    if (modelIt1 != models.end() && modelIt2 != models.end()) {
        std::iter_swap(modelIt1, modelIt2);
    }

    refreshStackPositions();
}

//��¼��������������ջ

void GameView::recordSwapAction(CardNode* clickedCard, CardNode* rightCard) {
    auto clickedModel = clickedCard->getModel();
    auto rightModel = rightCard->getModel();

    UndoAction action;
    action.description = "��������";

    action.undo = [this, clickedModel, rightModel]() {
        auto& cards = _stackController->getCardNodes();
        auto& models = _gameModel->handCards;

        int clickedIdx = -1, rightIdx = -1;
        for (int i = 0; i < (int)cards.size(); i++) {
            if (cards[i]->getModel() == clickedModel) clickedIdx = i;
            if (cards[i]->getModel() == rightModel) rightIdx = i;
        }

        if (clickedIdx == -1 || rightIdx == -1) {
            cocos2d::log("��������ʧ�ܣ������ѱ�����");
            return;
        }

        std::swap(cards[clickedIdx], cards[rightIdx]);
        std::swap(models[clickedIdx], models[rightIdx]);
        refreshStackPositions();
        };

    action.redo = [this, clickedModel, rightModel]() {
        auto& cards = _stackController->getCardNodes();
        auto& models = _gameModel->handCards;

        int clickedIdx = -1, rightIdx = -1;
        for (int i = 0; i < (int)cards.size(); i++) {
            if (cards[i]->getModel() == clickedModel) clickedIdx = i;
            if (cards[i]->getModel() == rightModel) rightIdx = i;
        }

        if (clickedIdx == -1 || rightIdx == -1) return;

        std::swap(cards[clickedIdx], cards[rightIdx]);
        std::swap(models[clickedIdx], models[rightIdx]);
        refreshStackPositions();
        };

    _undoManager->recordAction(action);
}

// ���¼��㲢�������������п���λ��
void GameView::refreshStackPositions() {
    auto& cards = _stackController->getCardNodes();
    if (cards.empty()) return;

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    float startX = origin.x + (visibleSize.width - (cards.size() - 1) * 80) / 2;
    float posY = origin.y + visibleSize.height * 0.3f;

    for (size_t i = 0; i < cards.size(); i++) {
        auto moveTo = MoveTo::create(0.2f, Vec2(startX + i * 80, posY));
        cards[i]->runAction(moveTo);
    }
}

// �����������ſ���
void GameView::eliminateCardsPermanent(CardNode* handCard, CardNode* playfieldCard) {
    if (!handCard || !playfieldCard) return;

    float duration = 0.3f;

    // ���ٶ���
    auto handFadeOut = FadeOut::create(duration);
    auto handScale = ScaleTo::create(duration, 0.1f);
    auto handRemove = RemoveSelf::create();
    handCard->runAction(Sequence::create(Spawn::create(handFadeOut, handScale, nullptr), handRemove, nullptr));

    auto playFadeOut = FadeOut::create(duration);
    auto playScale = ScaleTo::create(duration, 0.1f);
    auto playRemove = RemoveSelf::create();
    playfieldCard->runAction(Sequence::create(Spawn::create(playFadeOut, playScale, nullptr), playRemove, nullptr));

    // �ӿ������Ƴ�
    auto& stackCards = _stackController->getCardNodes();
    auto& playCards = _playFieldController->getCardNodes();

    stackCards.erase(std::remove(stackCards.begin(), stackCards.end(), handCard), stackCards.end());
    playCards.erase(std::remove(playCards.begin(), playCards.end(), playfieldCard), playCards.end());

    // ��ģ���Ƴ�
    auto& handModels = _gameModel->handCards;
    auto& playModels = _gameModel->playfieldCards;

    handModels.erase(std::remove(handModels.begin(), handModels.end(), handCard->getModel()), handModels.end());
    playModels.erase(std::remove(playModels.begin(), playModels.end(), playfieldCard->getModel()), playModels.end());

    // ������������г�����¼
    _undoManager->clear();

    // ���²���
    auto delay = DelayTime::create(duration);
    auto refresh = CallFunc::create([this]() {
        refreshStackPositions();
        });
    this->runAction(Sequence::create(delay, refresh, nullptr));

    // ���ʤ��
    if (handModels.empty() && playModels.empty()) {
        showVictoryMessage();
    }
}

// ������ť�������
void GameView::onUndoClicked() {
    _undoManager->undo();
}

// ��ʾʤ����Ϣ
void GameView::showVictoryMessage() {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto victoryLabel = Label::createWithSystemFont("ʤ��!", "Arial", 72);
    victoryLabel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    victoryLabel->setColor(Color3B::YELLOW);
    this->addChild(victoryLabel);

    auto fadeOut = FadeOut::create(0.5f);
    auto fadeIn = FadeIn::create(0.5f);
    auto sequence = Sequence::create(fadeOut, fadeIn, nullptr);
    auto repeat = RepeatForever::create(sequence);
    victoryLabel->runAction(repeat);
}

// �����ؿ�ѡ��ť
void GameView::createLevelButtons() {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    std::string path = Util::GetPatternPath() + "\\icon_5krbf9oz5hh";

    auto item1 = MenuItemImage::create(path + "\\number_one.png", path + "\\number_one.png", [this](Ref* sender) { loadLevel(1); });
    auto item2 = MenuItemImage::create(path + "\\number_two.png", path + "\\number_two.png", [this](Ref* sender) { loadLevel(2); });
    auto item3 = MenuItemImage::create(path + "\\number-three.png", path + "\\number-three.png", [this](Ref* sender) { loadLevel(3); });
    auto item4 = MenuItemImage::create(path + "\\weitaoshuzi4.png", path + "\\weitaoshuzi4.png", [this](Ref* sender) { loadLevel(4); });
    auto item5 = MenuItemImage::create(path + "\\weitaoshuzi5.png", path + "\\weitaoshuzi5.png", [this](Ref* sender) { loadLevel(5); });
    auto item6 = MenuItemImage::create(path + "\\weitaoshuzi6.png", path + "\\weitaoshuzi6.png", [this](Ref* sender) { loadLevel(6); });

    float scale = 0.5f;
    item1->setScale(scale);
    item2->setScale(scale);
    item3->setScale(scale);
    item4->setScale(scale);
    item5->setScale(scale);
    item6->setScale(scale);

    Size itemSize = item1->getContentSize() * scale;
    float spacing = 50;
    float totalWidth = 3 * itemSize.width + 2 * spacing;
    float startX = origin.x + (visibleSize.width - totalWidth) / 2 + itemSize.width / 2;

    float topY = origin.y + visibleSize.height * 0.6f;
    float bottomY = origin.y + visibleSize.height * 0.4f;

    item1->setPosition(Vec2(startX, topY));
    item2->setPosition(Vec2(startX + itemSize.width + spacing, topY));
    item3->setPosition(Vec2(startX + 2 * (itemSize.width + spacing), topY));
    item4->setPosition(Vec2(startX, bottomY));
    item5->setPosition(Vec2(startX + itemSize.width + spacing, bottomY));
    item6->setPosition(Vec2(startX + 2 * (itemSize.width + spacing), bottomY));

    auto menu = Menu::create(item1, item2, item3, item4, item5, item6, nullptr);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu);
}

// ����ָ���ؿ�
void GameView::loadLevel(int levelId) {
    _Scene = true;
    GameController::startGame(levelId);
}