﻿#pragma once
#include "cocos2d.h"
#include "PlayFieldController.h"
#include "StackController.h"
#include "UndoManager.h"
#include "GameModel.h"

// 场景切换标识
static bool _Scene = false;

// 主场景/游戏场景
class GameView : public cocos2d::Scene {
public:
    // 创建主场景
    static cocos2d::Scene* createScene();

    // 根据关卡加载的数据创建新场景和初始化
    static void startGame(std::shared_ptr<GameModel> model);

    // 初始化主场景
    virtual bool init() override;
    CREATE_FUNC(GameView);

    // ==================== 初始化方法 ====================

    // 初始化主场景
    void setupUI();

    // 初始化所有牌
    void setupControllers(std::shared_ptr<GameModel> model);

    // 设置牌按钮和背景
    void setupCardViews();

    // 设置游戏背景
    void setupGameBackground();


    // 返回主界面
    void returnToMainMenu();

    // 返回主界面时清空所有游戏场景资源
    void cleanupGame();

    // 处理卡牌点击事件
    void onCardClicked(CardNode* cardNode);

    // 处理撤销点击事件
    void onUndoClicked();

private:
    // 创建关卡按钮
    void createLevelButtons();

    // 加载关卡
    void loadLevel(int levelId);

    // 判断点击的牌是否和手牌顶部的牌能消除
    void handlePlayfieldEliminate(CardNode* playfieldCard);

    // 是否能交换手牌区的牌
    void handleStackSwap(CardNode* clickedCard);

    // 交换手牌区的牌
    void swapCards(CardNode* card1, CardNode* card2);

    // 消除要消除的牌
    void eliminateCardsPermanent(CardNode* handCard, CardNode* playfieldCard);

    // 交换后的牌记录信息
    void recordSwapAction(CardNode* clickedCard, CardNode* rightCard);

    // 交换完牌后的牌位置刷新
    void refreshStackPositions();

    // 单个牌添加事件
    void addCardTouchListener(CardNode* cardNode);

    // 设置事件回调
    void setupCardListeners();

    // 游戏结束
    void showVictoryMessage();


    // ==================== 成员变量 ====================

    std::unique_ptr<PlayFieldController> _playFieldController;  /// 场牌区控制器
    std::unique_ptr<StackController> _stackController;            /// 手牌区控制器
    std::unique_ptr<UndoManager> _undoManager;                      /// 撤销管理器
    std::shared_ptr<GameModel> _gameModel;                          /// 游戏数据模型
};