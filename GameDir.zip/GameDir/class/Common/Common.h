﻿#pragma once
#include <string>
#include <unordered_map>
#include "Util.hpp"

 // 屏幕尺寸常量
constexpr static int kMyheightMax = 1080;   ///< 屏幕最大高度
constexpr static int kMyweightMax = 2080;   ///< 屏幕最大宽度

// 卡牌花色类型枚举
enum CardSuitType {
    kCardSuitNone = -1,         ///< 无花色
    kCardSuitClubs,             ///< 梅花（♣）
    kCardSuitDiamonds,          ///< 方块（♦）
    kCardSuitHearts,            ///< 红桃（♥）
    kCardSuitSpades,            ///< 黑桃（♠）
    kCardSuitNumTypes           ///< 花色类型总数
};

// 卡牌牌面数字/字母枚举
enum CardFaceType {
    kCardFaceNone = -1,         ///< 无牌面
    kCardFaceAce,               ///< A
    kCardFaceTwo,               ///< 2
    kCardFaceThree,             ///< 3
    kCardFaceFour,              ///< 4
    kCardFaceFive,              ///< 5
    kCardFaceSix,               ///< 6
    kCardFaceSeven,             ///< 7
    kCardFaceEight,             ///< 8
    kCardFaceNine,              ///< 9
    kCardFaceTen,               ///< 10
    kCardFaceJack,              ///< J
    kCardFaceQueen,             ///< Q
    kCardFaceKing,              ///< K
    kCardFaceNumTypes           ///< 牌面类型总数
};

// 卡牌图案路径 单例类
class ResourcePaths {
public:
    // 获取单例实例
    static ResourcePaths& getInstance() {
        static ResourcePaths instance;
        return instance;
    }

    // 初始化
    void initPaths(const std::string& basePath) {
        _basePath = basePath;
        initBigNumberPaths();
        initSmallNumberPaths();
        initSuitPaths();
    }

    // 获取牌图片路径
    std::string getBigNumberPath(CardFaceType face) {
        return _bigNumbers[face];
    }
    std::string getSmallNumberPath(CardFaceType face) {
        return _smallNumbers[face];
    }
    std::string getSuitPath(CardSuitType suit) {
        return _suits[suit];
    }

private:
    ResourcePaths() {}

    // 初始化
    void initBigNumberPaths() {
        _bigNumbers[CardFaceType::kCardFaceAce] = _basePath + "\\big_red_A.png";
        _bigNumbers[CardFaceType::kCardFaceTwo] = _basePath + "\\big_red_2.png";
        _bigNumbers[CardFaceType::kCardFaceThree] = _basePath + "\\big_red_3.png";
        _bigNumbers[CardFaceType::kCardFaceFour] = _basePath + "\\big_red_4.png";
        _bigNumbers[CardFaceType::kCardFaceFive] = _basePath + "\\big_red_5.png";
        _bigNumbers[CardFaceType::kCardFaceSix] = _basePath + "\\big_red_6.png";
        _bigNumbers[CardFaceType::kCardFaceSeven] = _basePath + "\\big_red_7.png";
        _bigNumbers[CardFaceType::kCardFaceEight] = _basePath + "\\big_red_8.png";
        _bigNumbers[CardFaceType::kCardFaceNine] = _basePath + "\\big_red_9.png";
        _bigNumbers[CardFaceType::kCardFaceTen] = _basePath + "\\big_red_10.png";
        _bigNumbers[CardFaceType::kCardFaceJack] = _basePath + "\\big_red_J.png";
        _bigNumbers[CardFaceType::kCardFaceQueen] = _basePath + "\\big_red_Q.png";
        _bigNumbers[CardFaceType::kCardFaceKing] = _basePath + "\\big_red_K.png";
    }
    void initSmallNumberPaths() {
        _smallNumbers[CardFaceType::kCardFaceAce] = _basePath + "\\small_red_A.png";
        _smallNumbers[CardFaceType::kCardFaceTwo] = _basePath + "\\small_red_2.png";
        _smallNumbers[CardFaceType::kCardFaceThree] = _basePath + "\\small_red_3.png";
        _smallNumbers[CardFaceType::kCardFaceFour] = _basePath + "\\small_red_4.png";
        _smallNumbers[CardFaceType::kCardFaceFive] = _basePath + "\\small_red_5.png";
        _smallNumbers[CardFaceType::kCardFaceSix] = _basePath + "\\small_red_6.png";
        _smallNumbers[CardFaceType::kCardFaceSeven] = _basePath + "\\small_red_7.png";
        _smallNumbers[CardFaceType::kCardFaceEight] = _basePath + "\\small_red_8.png";
        _smallNumbers[CardFaceType::kCardFaceNine] = _basePath + "\\small_red_9.png";
        _smallNumbers[CardFaceType::kCardFaceTen] = _basePath + "\\small_red_10.png";
        _smallNumbers[CardFaceType::kCardFaceJack] = _basePath + "\\small_red_J.png";
        _smallNumbers[CardFaceType::kCardFaceQueen] = _basePath + "\\small_red_Q.png";
        _smallNumbers[CardFaceType::kCardFaceKing] = _basePath + "\\small_red_K.png";
    }
    void initSuitPaths() {
        std::string patternPath = Util::GetPatternPath();
        _suits[CardSuitType::kCardSuitClubs] = patternPath + "\\res\\res\\suits\\club.png";
        _suits[CardSuitType::kCardSuitDiamonds] = patternPath + "\\res\\res\\suits\\diamond.png";
        _suits[CardSuitType::kCardSuitHearts] = patternPath + "\\res\\res\\suits\\heart.png";
        _suits[CardSuitType::kCardSuitSpades] = patternPath + "\\res\\res\\suits\\spade.png";
    }
    std::string _basePath;                                              /// 资源基础路径
    std::unordered_map<CardFaceType, std::string> _bigNumbers;          /// 大数字图片路径映射
    std::unordered_map<CardFaceType, std::string> _smallNumbers;        /// 小数字图片路径映射
    std::unordered_map<CardSuitType, std::string> _suits;               /// 花色图片路径映射
};