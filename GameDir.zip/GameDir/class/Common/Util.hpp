#pragma once
#include <string>
#include <iostream>
#include <windows.h>

// �������·����Ӧ�Ŀ���/ͼƬ/��������·��
class Util {
public:
    static std::string GetMainPath()
    {
        // ��ȡ��ǰ·��
        char buffer[100];
        GetCurrentDirectoryA(100, buffer);
        std::string currentPath(buffer);

        return currentPath + "\\2.png";
    }

    static std::string GetPictuerPath()
    {
        char buffer[100];
        GetCurrentDirectoryA(100, buffer);
        std::string currentPath(buffer);
        return currentPath + "\\res\\res\\number";
    }
    static std::string GetPatternPath()
    {
        char buffer[100];
        GetCurrentDirectoryA(100, buffer);
        std::string currentPath(buffer);
        return currentPath;
    }
};